import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function generateZip() {
  const zip = new JSZip();
  const androidDir = path.resolve(process.cwd(), 'android');
  const publicDir = path.resolve(process.cwd(), 'public');

  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  function addFolderToZip(dirPath, zipFolder) {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        const subFolder = zipFolder.folder(entry.name);
        addFolderToZip(fullPath, subFolder);
      } else {
        const fileContent = fs.readFileSync(fullPath);
        zipFolder.file(entry.name, fileContent);
      }
    }
  }

  const rootFolder = zip.folder('OyunTurkce-AndroidTV-Studio');
  addFolderToZip(androidDir, rootFolder);

  // Ayrıca kök dizine .github iş akışı dosyasını da ekle
  const ghWorkflow = path.resolve(process.cwd(), '.github/workflows/build-apk.yml');
  if (fs.existsSync(ghWorkflow)) {
    rootFolder.folder('.github').folder('workflows').file('build-apk.yml', fs.readFileSync(ghWorkflow));
  }

  console.log('ZIP paketi sıkıştırılıyor...');
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  const outputPath = path.join(publicDir, 'OyunTurkce-AndroidTV-Studio.zip');
  fs.writeFileSync(outputPath, buffer);

  const stats = fs.statSync(outputPath);
  console.log(`ZIP başarıyla oluşturuldu: ${outputPath}`);
  console.log(`Dosya boyutu: ${stats.size} bayt (${(stats.size / 1024).toFixed(2)} KB)`);
}

generateZip().catch((err) => {
  console.error('Hata:', err);
  process.exit(1);
});
