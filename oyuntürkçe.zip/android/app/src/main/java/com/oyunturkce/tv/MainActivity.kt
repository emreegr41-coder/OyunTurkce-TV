package com.oyunturkce.tv

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // TV Ekranının Kapanmasını Engelle
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Android TV Tam Ekran Immersive Mode
        applyTvImmersiveMode()

        webView = findViewById(R.id.webView)
        configureTvWebView(webView)

        // Web varlıklarını yükle (file:///android_asset/dist/index.html)
        webView.loadUrl("file:///android_asset/dist/index.html")
    }

    private fun applyTvImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureTvWebView(view: WebView) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.webViewClient = WebViewClient()
        view.webChromeClient = WebChromeClient()
    }

    /**
     * Android TV D-Pad Kumanda Tuş Yakalama
     * Kumandadan basılan fiziksel TV tuşlarını (DPAD_CENTER, UP, DOWN, LEFT, RIGHT, BACK)
     * Web katmanına standart KeyEvent olarak aktarır.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    injectJsKeyEvent("Enter")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    injectJsKeyEvent("ArrowUp")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    injectJsKeyEvent("ArrowDown")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    injectJsKeyEvent("ArrowLeft")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    injectJsKeyEvent("ArrowRight")
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    injectJsKeyEvent("Escape")
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun injectJsKeyEvent(keyName: String) {
        val script = """
            (function() {
                var event = new KeyboardEvent('keydown', {
                    key: '$keyName',
                    code: '$keyName',
                    bubbles: true,
                    cancelable: true
                });
                document.dispatchEvent(event);
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyTvImmersiveMode()
        }
    }
}
