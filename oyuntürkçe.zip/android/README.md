# OyunTürkçe - Android TV Android Studio Projesi

Bu proje, PlayStation 5, Xbox ve PC konsol oyunlarında İngilizce altyazıları Türkçe'ye çevirmek üzere tasarlanmış bir Android TV uygulamasıdır.

## Proje İçeriği ve Yapısı:
- **`app/src/main/AndroidManifest.xml`**:
  - `android.hardware.touchscreen=false` (Android TV zorunluluğu)
  - `android.software.leanback=true`
  - `android.intent.category.LEANBACK_LAUNCHER` (TV ana ekran başlatıcısı)
  - `android:banner="@drawable/banner"` (16:9 TV afişi)
  - `android:screenOrientation="landscape"` (Yatay TV ekran kilidi)
- **`app/src/main/java/com/oyunturkce/tv/MainActivity.kt`**:
  - D-Pad kumanda tuş yakalama (`DPAD_CENTER`, `UP`, `DOWN`, `LEFT`, `RIGHT`, `BACK`)
  - Tam ekran Immersive Mode
  - `FLAG_KEEP_SCREEN_ON` ekran kararmasını önleme
- **`app/build.gradle.kts`**: `compileSdk 34`, `minSdk 24`, Android TV Leanback bağımlılıkları.
- **`settings.gradle.kts`**: Depolar ve proje modül yapılandırması.

## Android Studio ile APK Derleme Adımları:
1. Android Studio'yu açın.
2. **"Open"** seçeneğiyle bu klasörü seçin.
3. Gradle paket senkronizasyonunun bitmesini bekleyin (1-2 dakika).
4. Üst menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** yolunu izleyin.
5. Derleme bittiğinde `app/build/outputs/apk/debug/app-debug.apk` dosyasını televizyonunuza kurabilirsiniz!

## Not:
Bu ZIP paketi Android Studio kaynak kodlarını içerir. Binary `.apk` dosyası Android Studio veya GitHub Actions ile derlendikten sonra üretilir.
