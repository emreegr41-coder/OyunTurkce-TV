/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { NavigationTab, TvSettings } from './types';
import { TvHeader } from './components/TvHeader';
import { SubtitleRecognizerView } from './components/SubtitleRecognizerView';
import { ArchitectureNoticeView } from './components/ArchitectureNoticeView';
import { InstallationGuideView } from './components/InstallationGuideView';
import { SourceCodeApkView } from './components/SourceCodeApkView';
import { SettingsView } from './components/SettingsView';
import { TvRemoteSimulator } from './components/TvRemoteSimulator';
import { soundEffects } from './utils/soundEffects';

const DEFAULT_SETTINGS: TvSettings = {
  fontSize: 'large',
  textColor: 'yellow',
  bgOpacity: 75,
  textShadow: true,
  soundEffects: true,
  autoSpeak: false,
  speechSpeed: 1.0,
  showRemoteOverlay: true,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('recognizer');
  const [showRemote, setShowRemote] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [timeString, setTimeString] = useState<string>('12:00');

  const [settings, setSettings] = useState<TvSettings>(() => {
    try {
      const saved = localStorage.getItem('oyun_turkce_tv_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_SETTINGS;
  });

  // Saat güncellemesi
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(
        now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  // Ayarlar güncelleme
  const handleUpdateSettings = (newSettings: Partial<TvSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem('oyun_turkce_tv_settings', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleResetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    try {
      localStorage.removeItem('oyun_turkce_tv_settings');
    } catch {}
  };

  // Sesli okuma (TTS)
  const handleSpeak = useCallback((text: string, lang: 'tr' | 'en') => {
    if (!('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang === 'tr' ? 'tr-TR' : 'en-US';
      utterance.rate = settings.speechSpeed || 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Ses sentezleme desteklenmiyor:', e);
    }
  }, [settings.speechSpeed]);

  // Kumanda sesini aç/kapa
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundEffects.setEnabled(!nextMuted);
  };

  // Yazı boyutunu döngüsel değiştirme (Remote üzerindeki 'Boyut' tuşu için)
  const handleCycleFontSize = () => {
    const sizes: TvSettings['fontSize'][] = ['small', 'medium', 'large', 'extra-large'];
    const currentIdx = sizes.indexOf(settings.fontSize);
    const nextSize = sizes[(currentIdx + 1) % sizes.length];
    handleUpdateSettings({ fontSize: nextSize });
  };

  // D-Pad Navigasyonu
  const handleDpadMove = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
    const focusable = Array.from(
      document.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      )
    ).filter((el) => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && !el.hasAttribute('disabled');
    });

    if (focusable.length === 0) return;

    const activeElement = document.activeElement as HTMLElement | null;
    let nextIndex = 0;

    if (activeElement && focusable.includes(activeElement)) {
      const currentIndex = focusable.indexOf(activeElement);
      if (direction === 'down' || direction === 'right') {
        nextIndex = (currentIndex + 1) % focusable.length;
      } else {
        nextIndex = (currentIndex - 1 + focusable.length) % focusable.length;
      }
    }

    focusable[nextIndex]?.focus();
    focusable[nextIndex]?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, []);

  const handleSelect = useCallback(() => {
    const activeElement = document.activeElement as HTMLElement | null;
    if (activeElement && typeof activeElement.click === 'function') {
      activeElement.click();
    }
  }, []);

  const handleBack = useCallback(() => {
    if (activeTab !== 'recognizer') {
      setActiveTab('recognizer');
    }
  }, [activeTab]);

  // Fiziksel Klavye / Android TV Kumanda Tuş Dinleyicisi
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Input veya textarea içindeyken standart klavye yazımına müdahale etme
      const tagName = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (tagName === 'input' || tagName === 'textarea') return;

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        soundEffects.playFocusMove();
        handleDpadMove('up');
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        soundEffects.playFocusMove();
        handleDpadMove('down');
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        soundEffects.playFocusMove();
        handleDpadMove('left');
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        soundEffects.playFocusMove();
        handleDpadMove('right');
      } else if (e.key === 'Escape' || e.key === 'Backspace') {
        e.preventDefault();
        soundEffects.playFocusMove();
        handleBack();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDpadMove, handleBack]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Android TV Top Bar */}
      <TvHeader
        activeTab={activeTab}
        onTabChange={setActiveTab}
        showRemote={showRemote}
        onToggleRemote={() => setShowRemote(!showRemote)}
        timeString={timeString}
      />

      {/* Ana Görünüm Alanı */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'recognizer' && (
          <SubtitleRecognizerView
            settings={settings}
            onSpeak={handleSpeak}
          />
        )}

        {activeTab === 'architecture' && <ArchitectureNoticeView />}

        {activeTab === 'installation' && <InstallationGuideView />}

        {activeTab === 'apk_source' && <SourceCodeApkView />}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onResetSettings={handleResetSettings}
          />
        )}
      </main>

      {/* Ekran Altı TV Bildirim Şeridi */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-3 text-center text-xs text-slate-500">
        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
          <span>OyunTürkçe v1.0.0</span>
          <span>·</span>
          <span>Android TV 10-Foot UI</span>
          <span>·</span>
          <span>Cihaz İçi Ücretsiz OCR & Türkçe Oyun Sözlüğü</span>
          <span>·</span>
          <span>Sıfır PSN Şifre Talebi</span>
        </div>
      </footer>

      {/* Sanal TV Kumanda Simülatörü */}
      <TvRemoteSimulator
        isOpen={showRemote}
        onClose={() => setShowRemote(false)}
        onDpadMove={handleDpadMove}
        onSelect={handleSelect}
        onBack={handleBack}
        onToggleMute={handleToggleMute}
        isMuted={isMuted}
        onCycleFontSize={handleCycleFontSize}
      />
    </div>
  );
}
