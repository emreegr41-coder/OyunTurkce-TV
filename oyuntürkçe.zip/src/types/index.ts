export type NavigationTab = 'recognizer' | 'architecture' | 'installation' | 'apk_source' | 'settings';

export interface GamePreset {
  id: string;
  title: string;
  genre: string;
  platform: string;
  image: string;
  originalSubtitle: string;
  speaker: string;
  turkishTranslation: string;
  notes: string;
  // Subtitle crop region percentage [top%, left%, width%, height%]
  suggestedRoi: {
    top: number;
    left: number;
    width: number;
    height: number;
  };
}

export interface SubtitleResult {
  rawEnglishText: string;
  turkishTranslation: string;
  confidence: number;
  processingTimeMs: number;
  detectedWords: number;
  engineUsed: 'Tesseract.js (Cihaz İçi Ücretsiz OCR)' | 'Yerel Sözlük Eşleşmesi' | 'Yedek Ücretsiz Çeviri';
  speaker?: string;
  timestamp: string;
}

export interface TvSettings {
  fontSize: 'small' | 'medium' | 'large' | 'extra-large';
  textColor: 'yellow' | 'white' | 'cyan' | 'green';
  bgOpacity: number; // 0 to 100
  textShadow: boolean;
  soundEffects: boolean;
  autoSpeak: boolean;
  speechSpeed: number; // 0.75, 1.0, 1.25
  showRemoteOverlay: boolean;
}

export interface FeatureItem {
  id: string;
  title: string;
  status: 'active' | 'planned' | 'research';
  category: 'Görüntü İşleme' | 'Sistem Entegrasyonu' | 'Kullanıcı Deneyimi' | 'Çeviri Motoru';
  description: string;
  technicalDetails: string;
}
