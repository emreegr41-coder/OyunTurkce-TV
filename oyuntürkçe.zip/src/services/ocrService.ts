import { createWorker } from 'tesseract.js';

export interface PreprocessingOptions {
  grayscale?: boolean;
  threshold?: number; // 0 to 255
  invert?: boolean;
  contrast?: number; // multiplier e.g. 1.5
}

let cachedWorker: any = null;
let isWorkerInitializing = false;

/**
 * Tesseract.js Worker'ını başlatır veya önbellekten döndürür.
 * Tamamen cihaz üzerinde (offline WebAssembly) çalışır.
 */
export async function getOcrWorker(onProgress?: (progress: number, status: string) => void) {
  if (cachedWorker) {
    return cachedWorker;
  }

  if (isWorkerInitializing) {
    // Biraz bekle
    await new Promise((r) => setTimeout(r, 400));
    if (cachedWorker) return cachedWorker;
  }

  isWorkerInitializing = true;
  try {
    const worker = await createWorker('eng', 1, {
      logger: (m) => {
        if (onProgress && m.status) {
          onProgress(m.progress || 0, m.status);
        }
      }
    });
    cachedWorker = worker;
    return worker;
  } catch (err) {
    console.warn('Tesseract worker başlatılırken hata, recognize metoduna geçilecek:', err);
    throw err;
  } finally {
    isWorkerInitializing = false;
  }
}

/**
 * Görüntüden altyazı bölgesini (ROI) kırpar ve oyun altyazılarını
 * daha net okumak için kontrast/eşikleme filtresi uygular.
 */
export function preprocessSubtitleImage(
  imageSource: HTMLImageElement | HTMLCanvasElement,
  roi: { top: number; left: number; width: number; height: number }, // Yüzdelik değerler 0-100
  options: PreprocessingOptions = { grayscale: true, contrast: 1.6, threshold: 160 }
): { processedDataUrl: string; croppedWidth: number; croppedHeight: number } {
  const canvas = document.createElement('canvas');
  const naturalWidth = 'naturalWidth' in imageSource ? imageSource.naturalWidth || imageSource.width : imageSource.width;
  const naturalHeight = 'naturalHeight' in imageSource ? imageSource.naturalHeight || imageSource.height : imageSource.height;

  // Gerçek piksel koordinatlarını hesapla
  const cropX = Math.round((roi.left / 100) * naturalWidth);
  const cropY = Math.round((roi.top / 100) * naturalHeight);
  const cropW = Math.round((roi.width / 100) * naturalWidth);
  const cropH = Math.round((roi.height / 100) * naturalHeight);

  canvas.width = Math.max(cropW, 100);
  canvas.height = Math.max(cropH, 40);

  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    throw new Error('Canvas bağlamı oluşturulamadı.');
  }

  // Kırpılan bölgeyi çiz
  ctx.drawImage(
    imageSource,
    cropX,
    cropY,
    cropW,
    cropH,
    0,
    0,
    canvas.width,
    canvas.height
  );

  // Piksel kontrastı ve parlaklık eşikleme filtresi (Oyun altyazıları için optimize edilmiş)
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  const contrast = options.contrast ?? 1.5;
  const threshold = options.threshold ?? 150;
  const factor = (259 * (contrast * 100 + 255)) / (255 * (259 - contrast * 100));

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Parlaklık hesabı (Luminance)
    let gray = 0.299 * r + 0.587 * g + 0.114 * b;

    // Kontrast çarpanı
    gray = factor * (gray - 128) + 128;
    gray = Math.min(255, Math.max(0, gray));

    // Altyazı yazıları genelde parlak (beyaz/sarı) olduğundan eşikleme
    if (gray >= threshold) {
      data[i] = 255;
      data[i + 1] = 255;
      data[i + 2] = 255;
    } else {
      data[i] = 0;
      data[i + 1] = 0;
      data[i + 2] = 0;
    }
  }

  ctx.putImageData(imageData, 0, 0);

  return {
    processedDataUrl: canvas.toDataURL('image/png'),
    croppedWidth: canvas.width,
    croppedHeight: canvas.height
  };
}

/**
 * Verilen görsel veya kırpılmış alandan İngilizce metni tanır.
 */
export async function recognizeEnglishSubtitle(
  imageSource: HTMLImageElement | HTMLCanvasElement | string,
  roi?: { top: number; left: number; width: number; height: number },
  onProgress?: (progress: number, status: string) => void
): Promise<{ text: string; confidence: number; durationMs: number; processedImagePreview?: string }> {
  const startTime = performance.now();
  let imageToRecognize: string | HTMLImageElement | HTMLCanvasElement = imageSource;
  let previewUrl: string | undefined;

  // Eğer ROI verilmişse ve kaynak bir DOM görseli ise ön işlemden geçir
  if (roi && typeof imageSource !== 'string') {
    const { processedDataUrl } = preprocessSubtitleImage(imageSource, roi);
    imageToRecognize = processedDataUrl;
    previewUrl = processedDataUrl;
  }

  try {
    const worker = await getOcrWorker(onProgress);
    const ret = await worker.recognize(imageToRecognize);

    const endTime = performance.now();
    let text = (ret.data.text || '').trim();

    // OCR artıkları ve fazladan boşlukları temizle
    text = text.replace(/[\r\n]+/g, ' ').replace(/\s{2,}/g, ' ');

    return {
      text,
      confidence: Math.round(ret.data.confidence || 85),
      durationMs: Math.round(endTime - startTime),
      processedImagePreview: previewUrl
    };
  } catch (error) {
    console.error('OCR tanıma hatası:', error);
    throw error;
  }
}
