export interface ProjectFileDefinition {
  id: string;
  name: string;
  path: string;
  lang: string;
  category: 'Manifest' | 'Gradle' | 'Kotlin' | 'Resources' | 'Config';
  description: string;
  content: string;
}

export const ANDROID_STUDIO_FILES: Record<string, ProjectFileDefinition> = {
  manifest: {
    id: 'manifest',
    name: 'AndroidManifest.xml',
    path: 'app/src/main/AndroidManifest.xml',
    lang: 'xml',
    category: 'Manifest',
    description: 'Android TV için zorunlu Leanback, touchscreen=false, TV afişi (banner) ve landscape yönlendirme yapılandırması.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.oyunturkce.tv">

    <!-- 1. DOKUNMATİK EKRAN: TV'lerde dokunmatik ekran olmadığından zorunludur -->
    <uses-feature
        android:name="android.hardware.touchscreen"
        android:required="false" />

    <!-- 2. LEANBACK DESTEĞİ: Android TV ana ekranı ve kumanda arayüzü -->
    <uses-feature
        android:name="android.software.leanback"
        android:required="false" />

    <!-- 3. OYUN KUMANDASI / D-PAD DONANIMI -->
    <uses-feature
        android:name="android.hardware.gamepad"
        android:required="false" />

    <!-- 4. İSTEĞE BAĞLI USB VİDEO YAKALAMA KARTI (UVC Capture Card) -->
    <uses-feature
        android:name="android.hardware.usb.host"
        android:required="false" />

    <!-- Gerekli Ağ ve Depolama İzinleri -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.OyunTurkceTv"
        android:banner="@drawable/banner"
        android:hardwareAccelerated="true">

        <!-- Ana TV Etkinliği (MainActivity) -->
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.OyunTurkceTv.NoActionBar"
            android:screenOrientation="landscape"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:launchMode="singleTask">

            <!-- Standart Başlatıcı (Telefon/Tablet Uyumluluğu) -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- ANDROID TV LEANBACK BAŞLATICI (TV'nin Ana Sayfasında Görünmesi İçin Şart) -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>

    </application>
</manifest>`
  },

  mainActivity: {
    id: 'mainActivity',
    name: 'MainActivity.kt',
    path: 'app/src/main/java/com/oyunturkce/tv/MainActivity.kt',
    lang: 'kotlin',
    category: 'Kotlin',
    description: 'Android TV kumanda tuşlarını (D-Pad Center/OK, Up, Down, Left, Right, Back) yakalayan ve tam ekran Immersive Mode uygulayan ana etkinlik.',
    content: `package com.oyunturkce.tv

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // TV Ekranının Kapanmasını Engelle (Ekran Açık Kalsın)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Android TV Tam Ekran Immersive Mode
        applyTvImmersiveMode()

        webView = findViewById(R.id.webView)
        configureTvWebView(webView)

        // Uygulama yerel HTML paketini yükler
        // Proje varlıkları app/src/main/assets/dist/index.html altındadır
        webView.loadUrl("file:///android_asset/dist/index.html")
    }

    private fun applyTvImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureTvWebView(view: WebView) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.webViewClient = WebViewClient()
        view.webChromeClient = WebChromeClient()
    }

    /**
     * Android TV D-Pad Kumanda Tuş Yakalama
     * Kumandadan basılan fiziksel TV tuşlarını (DPAD_CENTER, UP, DOWN, LEFT, RIGHT, BACK)
     * Web katmanına standart KeyEvent olarak aktarır.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    injectJsKeyEvent("Enter")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    injectJsKeyEvent("ArrowUp")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    injectJsKeyEvent("ArrowDown")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    injectJsKeyEvent("ArrowLeft")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    injectJsKeyEvent("ArrowRight")
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    injectJsKeyEvent("Escape")
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun injectJsKeyEvent(keyName: String) {
        val script = """
            (function() {
                var event = new KeyboardEvent('keydown', {
                    key: '$keyName',
                    code: '$keyName',
                    bubbles: true,
                    cancelable: true
                });
                document.dispatchEvent(event);
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyTvImmersiveMode()
        }
    }
}`
  },

  buildGradleApp: {
    id: 'buildGradleApp',
    name: 'build.gradle.kts (App)',
    path: 'app/build.gradle.kts',
    lang: 'kotlin',
    category: 'Gradle',
    description: 'Uygulama seviyesi Gradle yapılandırması: Leanback UI kütüphanesi, minSdk 24 (Android TV), ProGuard kuralları ve release imzalama.',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.oyunturkce.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.oyunturkce.tv"
        minSdk = 24 // Android 7.0+ (Tüm modern Android TV ve Google TV cihazlarını kapsar)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Prototip kolaylığı için debug imzası
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    sourceSets {
        getByName("main") {
            assets.srcDirs("src/main/assets")
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)

    // Android TV Leanback Kütüphaneleri
    implementation("androidx.leanback:leanback:1.0.0")
    implementation("androidx.leanback:leanback-preference:1.0.0")

    // WebView & WebRTC Video Yakalama Desteği
    implementation("androidx.webkit:webkit:1.10.0")

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}`
  },

  buildGradleProject: {
    id: 'buildGradleProject',
    name: 'build.gradle.kts (Project)',
    path: 'build.gradle.kts',
    lang: 'kotlin',
    category: 'Gradle',
    description: 'Proje kök dizini Gradle yapılandırması: Android Gradle Plugin (AGP) 8.3+ ve Kotlin 1.9+ bağımlılık eklentileri.',
    content: `// OyunTürkçe Android TV Proje Kök Gradle Dosyası
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}`
  },

  settingsGradle: {
    id: 'settingsGradle',
    name: 'settings.gradle.kts',
    path: 'settings.gradle.kts',
    lang: 'kotlin',
    category: 'Gradle',
    description: 'Android Studio proje depoları (Google Maven, Maven Central) ve modül tanımlamaları.',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "OyunTurkceTV"
include(":app")`
  },

  libsVersionToml: {
    id: 'libsVersionToml',
    name: 'libs.versions.toml',
    path: 'gradle/libs.versions.toml',
    lang: 'toml',
    category: 'Gradle',
    description: 'Modern Android Studio Version Catalog dosyası. Bağımlılık ve eklenti sürümlerini yönetir.',
    content: `[versions]
agp = "8.3.1"
kotlin = "1.9.22"
coreKtx = "1.12.0"
junit = "4.13.2"
junitVersion = "1.1.5"
espressoCore = "3.5.1"
appcompat = "1.6.1"
material = "1.11.0"
constraintlayout = "2.1.4"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
junit = { group = "junit", name = "junit", version.ref = "junit" }
androidx-junit = { group = "androidx.test.ext", name = "junit", version.ref = "junitVersion" }
androidx-espresso-core = { group = "androidx.test.espresso", name = "espresso-core", version.ref = "espressoCore" }
androidx-appcompat = { group = "androidx.appcompat", name = "appcompat", version.ref = "appcompat" }
material = { group = "com.google.android.material", name = "material", version.ref = "material" }
androidx-constraintlayout = { group = "androidx.constraintlayout", name = "constraintlayout", version.ref = "constraintlayout" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }`
  },

  activityLayout: {
    id: 'activityLayout',
    name: 'activity_main.xml',
    path: 'app/src/main/res/layout/activity_main.xml',
    lang: 'xml',
    category: 'Resources',
    description: 'Ana etkinlik layout dosyası: Tam ekran donanım hızlandırmalı WebView kapsayıcısı.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#020617">

    <WebView
        android:id="@+id/webView"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="#020617" />

</FrameLayout>`
  },

  stringsXml: {
    id: 'stringsXml',
    name: 'strings.xml',
    path: 'app/src/main/res/values/strings.xml',
    lang: 'xml',
    category: 'Resources',
    description: 'Uygulama adı ve Türkçe metin kaynakları.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">OyunTürkçe</string>
    <string name="title_activity_main">OyunTürkçe TV Altyazı Çevirici</string>
    <string name="banner_description">Konsol oyunları için Türkçe altyazı çeviri uygulaması</string>
</resources>`
  },

  bannerXml: {
    id: 'bannerXml',
    name: 'banner.xml (TV Leanback Afişi)',
    path: 'app/src/main/res/drawable/banner.xml',
    lang: 'xml',
    category: 'Resources',
    description: 'Android TV ana ekranındaki "Uygulamalar" satırında görünecek 16:9 oranlı vektörel TV afişi.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="320dp"
    android:height="180dp"
    android:viewportWidth="320"
    android:viewportHeight="180">
    <!-- Arka Plan Lacivert Degrade -->
    <path
        android:pathData="M0,0h320v180h-320z"
        android:fillColor="#090E17"/>
    <!-- Vurgulu Çizgiler -->
    <path
        android:pathData="M0,0 L320,180"
        android:strokeColor="#1E293B"
        android:strokeWidth="2"/>
    <path
        android:pathData="M320,0 L0,180"
        android:strokeColor="#0F172A"
        android:strokeWidth="1.5"/>
    <!-- Oyun Kumandası Vurgu Parçası -->
    <path
        android:pathData="M110,90 C110,75 130,65 160,65 C190,65 210,75 210,90 C210,110 195,125 180,125 C170,125 165,115 160,115 C155,115 150,125 140,125 C125,125 110,110 110,90 Z"
        android:fillColor="#0284C7"/>
    <!-- Altyazı Simgesi -->
    <path
        android:pathData="M135,88 h50 M142,96 h36"
        android:strokeColor="#FFFFFF"
        android:strokeWidth="3"
        android:strokeLineCap="round"/>
</vector>`
  },

  gradleProperties: {
    id: 'gradleProperties',
    name: 'gradle.properties',
    path: 'gradle.properties',
    lang: 'properties',
    category: 'Config',
    description: 'JVM bellek tahsisi ve AndroidX geçiş ayarları.',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
android.nonTransitiveRClass=true`
  }
};
