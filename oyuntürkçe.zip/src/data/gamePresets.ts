import { GamePreset } from '../types';

export const GAME_PRESETS: GamePreset[] = [
  {
    id: 'cyberpunk-2077',
    title: 'Cyberpunk 2077',
    genre: 'Aksiyon RPG / Distopik Bilimkurgu',
    platform: 'PlayStation 5 / Xbox Series X / PC',
    image: '/src/assets/images/sample_cyberpunk_dialogue_1792872227571.jpg',
    speaker: 'Johnny Silverhand / V',
    originalSubtitle: 'Wake up, samurai. We have a city to burn.',
    turkishTranslation: 'Uyan, samuray. Yakacak bir şehrimiz var.',
    notes: 'Karanlık neon yağmurlu sahnelerde alt altyazı şeridi yüksek kontrastlı beyaz metin içerir.',
    suggestedRoi: {
      top: 72,
      left: 20,
      width: 60,
      height: 16
    }
  },
  {
    id: 'witcher-3',
    title: 'The Witcher 3: Wild Hunt',
    genre: 'Karanlık Fantastik RPG',
    platform: 'PlayStation 5 / Xbox / PC',
    image: '/src/assets/images/sample_witcher_dialogue_1792872227096.jpg',
    speaker: 'Geralt of Rivia',
    originalSubtitle: "Geralt: Evil is evil. Lesser, greater, middling, it's all the same.",
    turkishTranslation: 'Geralt: Kötülük kötülüktür. Azı, çoğu veya ortası yoktur, hepsi birdir.',
    notes: 'Doğal orman arka planı ve karakter konuşmacı ismiyle gelen klasik RPG altyazı stili.',
    suggestedRoi: {
      top: 65,
      left: 15,
      width: 70,
      height: 18
    }
  },
  {
    id: 'god-of-war-ragnarok',
    title: 'God of War Ragnarök',
    genre: 'Mitolojik Aksiyon Macera',
    platform: 'PlayStation 5 / PS4',
    image: '/src/assets/images/sample_godofwar_dialogue_1792872228679.jpg',
    speaker: 'Kratos',
    originalSubtitle: "Don't be sorry, boy. Be better.",
    turkishTranslation: 'Özür dileme evlat. Daha iyi ol.',
    notes: 'Karlar arasındaki savaşçı diyalogları. Altta ortalanmış temiz altyazı konumu.',
    suggestedRoi: {
      top: 78,
      left: 25,
      width: 50,
      height: 14
    }
  }
];
