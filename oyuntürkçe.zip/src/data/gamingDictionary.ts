/**
 * OyunTürkçe Yerel ve Ücretsiz Çeviri Sözlüğü
 * Hiçbir ücretli API (Google Cloud Translation, OpenAI, DeepL Pro vb.) gerektirmez.
 * Cihaz üzerinde (Android TV belleğinde) çalışır.
 */

export interface TranslationDictionaryEntry {
  en: string;
  tr: string;
  context?: string;
}

// Özel oyun diyalogları ve ünlü replikler
export const FAMOUS_GAME_DIALOGUES: Record<string, string> = {
  "wake up, samurai. we have a city to burn.": "Uyan samuray. Yakacak bir şehrimiz var.",
  "wake up samurai we have a city to burn": "Uyan samuray. Yakacak bir şehrimiz var.",
  "evil is evil. lesser, greater, middling, it's all the same.": "Kötülük kötülüktür. Azı, çoğu veya ortası yoktur, hepsi birdir.",
  "evil is evil lesser greater middling it's all the same": "Kötülük kötülüktür. Azı, çoğu veya ortası yoktur, hepsi birdir.",
  "don't be sorry, boy. be better.": "Özür dileme çocuk. Daha iyi ol.",
  "don't be sorry boy be better": "Özür dileme çocuk. Daha iyi ol.",
  "stay awhile and listen": "Biraz kal ve dinle.",
  "the cake is a lie": "Pasta bir yalan.",
  "war. war never changes.": "Savaş. Savaş asla değişmez.",
  "praise the sun!": "Güneşi yücelt!",
  "you died": "ÖLDÜN",
  "finish him!": "İŞİNİ BİTİR!",
  "would you kindly": "Lütfen nezaket gösterip...",
  "i used to be an adventurer like you, then i took an arrow in the knee.": "Ben de eskiden senin gibi bir maceracıydım, ta ki dizime bir ok yiyene dek.",
  "press f to pay respects": "Saygını göstermek için F tuşuna bas.",
  "ah shit, here we go again.": "Hay aksi, yine başlıyoruz.",
  "nothing is true, everything is permitted.": "Hiçbir şey doğru değildir, her şey mübahtır.",
  "a man chooses, a slave obeys.": "İnsan seçer, köle itaat eder.",
  "it's dangerous to go alone! take this.": "Yalnız gitmek tehlikelidir! Bunu al.",
  "protect the objective": "Hedefi koru.",
  "mission failed": "Görev Başarısız Oldu.",
  "mission accomplished": "Görev Tamamlandı.",
  "quest updated": "Görev Güncellendi.",
  "level up!": "Seviye Atladın!",
  "headshot": "Kafadan Vuruş",
  "low health! take cover!": "Düşük can! Siper al!",
  "enemy spotted": "Düşman tespit edildi.",
  "checkpoint reached": "Kontrol noktasına ulaşıldı."
};

// Yaygın oyun içi diyalog ve arayüz terimleri sözlüğü
export const GAMING_TERMS_DICTIONARY: Record<string, string> = {
  // Eylemler ve Emirler
  "attack": "saldır",
  "defend": "savun",
  "run": "koş",
  "jump": "zıpla",
  "crouch": "çömel",
  "reload": "şarjör doldur",
  "shoot": "ateş et",
  "interact": "etkileşime gir",
  "examine": "incele",
  "talk": "konuş",
  "listen": "dinle",
  "follow": "takip et",
  "wait": "bekle",
  "flee": "kaç",
  "survive": "hayatta kal",
  "destroy": "yok et",
  "heal": "iyileştir",
  "revive": "canlandır",
  "equip": "kuşan",
  "drop": "bırak",
  "inventory": "envanter",
  "craft": "üret",
  "upgrade": "yükselt",

  // Durumlar ve Varlıklar
  "enemy": "düşman",
  "allies": "müttefikler",
  "ally": "müttefik",
  "boss": "bölüm sonu canavarı",
  "monster": "canavar",
  "weapon": "silah",
  "shield": "kalkan",
  "armor": "zırh",
  "sword": "kılıç",
  "bow": "yay",
  "arrow": "ok",
  "potion": "iksir",
  "health": "can / sağlık",
  "stamina": "dayanıklılık",
  "mana": "büyü gücü",
  "damage": "hasar",
  "critical": "kritik",
  "stealth": "gizlilik",

  // Diyalog kalıpları
  "wake up": "uyan",
  "samurai": "samuray",
  "we have": "sahibiz / var",
  "a city": "bir şehir",
  "to burn": "yakacak",
  "evil is evil": "kötülük kötülüktür",
  "lesser": "daha azı",
  "greater": "daha büyüğü",
  "middling": "ortası",
  "it's all the same": "hepsi aynı / birdir",
  "don't be sorry": "özür dileme",
  "boy": "çocuk / oğlum",
  "be better": "daha iyi ol",
  "father": "baba",
  "mother": "anne",
  "brother": "kardeş",
  "look at me": "bana bak",
  "we must go": "gitmeliyiz",
  "hurry": "acele et",
  "be careful": "dikkatli ol",
  "where are you": "neredesin",
  "who are you": "kimsin sen",
  "i am ready": "ben hazırım",
  "trust me": "bana güven",
  "help me": "bana yardım et",
  "stay back": "geride dur",
  "take this": "bunu al",
  "no way": "olamaz / imkansız",
  "let's go": "hadi gidelim",
  "come on": "hadi ama",
  "behind you": "arkanda",
  "get down": "yere yat"
};

/**
 * Ücretsiz yerel çevirici:
 * 1. Tam cümle eşleşmesi kontrol edilir (ünlü replikler & oyun diyalogları).
 * 2. Cümle temizlenir, konuşmacı ayrıştırılır ("Geralt: ...").
 * 3. Kelime ve deyim tabanlı akıllı yerel eşleme uygulanır.
 * 4. Ağ bağlantısı varsa ücretsiz açık MyMemory servisiyle zenginleştirilir (API Anahtarsız).
 */
export async function translateTextToTurkish(englishText: string): Promise<{
  translation: string;
  source: 'Yerel Sözlük Eşleşmesi' | 'Yedek Ücretsiz Çeviri';
  speaker?: string;
}> {
  const trimmed = englishText.trim();
  if (!trimmed) {
    return {
      translation: '',
      source: 'Yerel Sözlük Eşleşmesi'
    };
  }

  // Konuşmacı tespiti (Örn: "Geralt: Evil is evil" veya "Kratos: Don't be sorry")
  let speaker: string | undefined;
  let textToTranslate = trimmed;

  const speakerMatch = trimmed.match(/^([A-Za-z0-9_\s]{2,20}):\s*(.+)$/i);
  if (speakerMatch) {
    speaker = speakerMatch[1].trim();
    textToTranslate = speakerMatch[2].trim();
  }

  const normalizedLower = textToTranslate
    .toLowerCase()
    .replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();

  // 1. Tam replik eşleşmesi kontrolü
  for (const [key, trVal] of Object.entries(FAMOUS_GAME_DIALOGUES)) {
    const normKey = key
      .toLowerCase()
      .replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "")
      .replace(/\s{2,}/g, " ")
      .trim();
    if (normalizedLower === normKey || normalizedLower.includes(normKey) || normKey.includes(normalizedLower)) {
      const fullText = speaker ? `${speaker}: ${trVal}` : trVal;
      return {
        translation: fullText,
        source: 'Yerel Sözlük Eşleşmesi',
        speaker
      };
    }
  }

  // 2. Ücretsiz açık API çağrısı denemesi (Hiçbir anahtar veya hesap gerektirmez)
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);

    const encoded = encodeURIComponent(textToTranslate);
    const res = await fetch(`https://api.mymemory.translated.net/get?q=${encoded}&langpair=en|tr`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && data.responseData && data.responseData.translatedText) {
        let translated = data.responseData.translatedText;
        // HTML entity temizliği
        translated = translated
          .replace(/&#39;/g, "'")
          .replace(/&quot;/g, '"')
          .replace(/&amp;/g, '&');

        const result = speaker ? `${speaker}: ${translated}` : translated;
        return {
          translation: result,
          source: 'Yedek Ücretsiz Çeviri',
          speaker
        };
      }
    }
  } catch (err) {
    // Ağ yoksa veya zaman aşımına uğrarsa offline yerel sözlüğe sessizce düşer
    console.debug('Açık çeviri servisi zaman aşımı, yerel sözlüğe geçiliyor:', err);
  }

  // 3. Yerel sözlük kelime ve deyim bazlı çevirici
  const words = textToTranslate.split(/\s+/);
  const translatedWords = words.map(w => {
    const cleanWord = w.toLowerCase().replace(/[^a-z]/g, '');
    if (GAMING_TERMS_DICTIONARY[cleanWord]) {
      return GAMING_TERMS_DICTIONARY[cleanWord];
    }
    return w;
  });

  const fallbackTranslation = translatedWords.join(' ');
  const finalResult = speaker ? `${speaker}: ${fallbackTranslation}` : fallbackTranslation;

  return {
    translation: finalResult,
    source: 'Yerel Sözlük Eşleşmesi',
    speaker
  };
}
