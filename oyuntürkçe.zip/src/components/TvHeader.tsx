import React from 'react';
import { NavigationTab } from '../types';
import { soundEffects } from '../utils/soundEffects';
import { Tv, Radio, Terminal, Settings2, ShieldAlert } from 'lucide-react';

interface TvHeaderProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  showRemote: boolean;
  onToggleRemote: () => void;
  timeString: string;
}

export const TvHeader: React.FC<TvHeaderProps> = ({
  activeTab,
  onTabChange,
  showRemote,
  onToggleRemote,
  timeString,
}) => {
  const tabs: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'recognizer', label: 'Altyazı Çevirici (Prototip)', icon: <Tv className="w-4 h-4" /> },
    { id: 'architecture', label: 'Teknik Sınırlar & HDCP', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'installation', label: 'TV Kurulum Rehberi', icon: <Radio className="w-4 h-4" /> },
    { id: 'apk_source', label: 'APK & Kaynak Kodu', icon: <Terminal className="w-4 h-4" /> },
    { id: 'settings', label: 'TV Ayarları', icon: <Settings2 className="w-4 h-4" /> },
  ];

  const handleSelectTab = (tab: NavigationTab) => {
    soundEffects.playSelect();
    onTabChange(tab);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3 flex items-center justify-between gap-8 text-slate-100">
      {/* Zone 1: Single-element brand wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-9 h-9 rounded-lg bg-cyan-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold">
          O<span className="text-amber-400">T</span>
        </div>
        <div className="flex flex-col">
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            OyunTürkçe
          </span>
          <span className="text-[11px] text-slate-400 hidden sm:block">
            Android TV Konsol Çevirici
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links (Clean single line, TV focusable) */}
      <nav className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1" aria-label="TV Menü">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleSelectTab(tab.id)}
              onFocus={() => soundEffects.playFocusMove()}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 scale-[1.02]'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800'
              } focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-2 focus:ring-offset-slate-950`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1 Primary Action (ZIP İndir + Kumanda Simülatörü Aç/Kapat + Saat) */}
      <div className="flex items-center gap-2.5 shrink-0">
        <a
          href="/OyunTurkce-AndroidTV-Studio.zip"
          download="OyunTurkce-AndroidTV-Studio.zip"
          onClick={() => soundEffects.playSuccess()}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/40 text-cyan-300 text-xs font-semibold transition-colors cursor-pointer"
          title="Android Studio Projesini ZIP Olarak İndir"
        >
          <span>ZIP İndir</span>
          <span className="text-[10px] text-cyan-400 font-mono">11KB</span>
        </a>

        <span className="text-xs font-mono text-slate-400 tabular-nums hidden lg:inline-block">
          {timeString}
        </span>

        <button
          onClick={() => {
            soundEffects.playSelect();
            onToggleRemote();
          }}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer border ${
            showRemote
              ? 'bg-amber-400/10 border-amber-400/40 text-amber-300'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
          } focus:outline-none focus:ring-2 focus:ring-amber-400`}
          title="TV Kumanda Kontrol Panelini Aç/Kapat"
        >
          <span>Kumanda</span>
          <span className="text-[10px] px-1 py-0.2 bg-slate-800 rounded text-slate-400">
            {showRemote ? 'Açık' : 'Kapalı'}
          </span>
        </button>
      </div>
    </header>
  );
};
