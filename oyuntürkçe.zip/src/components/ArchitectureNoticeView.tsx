import React from 'react';
import { FeatureItem } from '../types';
import {
  CheckCircle2,
  Clock,
  ShieldCheck,
  Tv,
  Cable,
  Smartphone,
  AlertTriangle,
  Lock,
  Cpu,
  Layers,
  FileCode2
} from 'lucide-react';

export const ArchitectureNoticeView: React.FC = () => {
  const features: FeatureItem[] = [
    {
      id: 'f1',
      title: 'Cihaz Üzeri Görüntüden Altyazı Tanıma (OCR)',
      status: 'active',
      category: 'Görüntü İşleme',
      description: 'Seçilen oyun ekran görüntüsü veya fotoğraftaki İngilizce altyazıyı Tesseract.js ile cihaz içinde sıfır maliyetle okuma.',
      technicalDetails: 'Tesseract.js (WASM/Worker) + HTML5 Canvas binarize kontrast ön filtreleme.'
    },
    {
      id: 'f2',
      title: 'Türkçe Oyun Çeviri Motoru',
      status: 'active',
      category: 'Çeviri Motoru',
      description: 'Ücretli Google Cloud / DeepL API anahtarı gerektirmeyen yerel oyun sözlüğü ve açık çeviri eşleştiricisi.',
      technicalDetails: '500+ oyun repliği & RPG terim sözlüğü + açık yedek REST çeviri.'
    },
    {
      id: 'f3',
      title: 'Android TV 10-Foot D-Pad Kumanda Deneyimi',
      status: 'active',
      category: 'Kullanıcı Deneyimi',
      description: 'Televizyon kumandası ile rahat gezinme, yüksek kontrastlı odak halkaları, 3 metre koltuk mesafesi okunabilirliği.',
      technicalDetails: 'Standart W3C KeyEvent (ArrowUp/Down/Left/Right, Enter, Escape) + Web Audio TV ses efektleri.'
    },
    {
      id: 'f4',
      title: 'Altyazı Bölgesi (ROI) Kırpma & Canlı TV Katmanı',
      status: 'active',
      category: 'Kullanıcı Deneyimi',
      description: 'Oyun içi HUD elemanlarını filtreleyip yalnızca altyazı şeridini hedefleme ve televizyon ekranında altyazı katmanı simülasyonu.',
      technicalDetails: 'Görsel piksel yüzdelik koordinatlandırması ve yüksek kontrastlı sarı/beyaz TV altyazı stili.'
    },
    {
      id: 'f5',
      title: 'Sesli Okuma (TTS) Desteği',
      status: 'active',
      category: 'Kullanıcı Deneyimi',
      description: 'Çevrilen Türkçe metni veya orijinal İngilizce cümleyi sesli olarak dinleme.',
      technicalDetails: 'Web Speech API / Android Text-To-Speech altyapısı.'
    },
    {
      id: 'f6',
      title: 'USB UVC Video Yakalama Kartı (Capture Card) Akışı',
      status: 'planned',
      category: 'Görüntü İşleme',
      description: 'Android TV\'nin USB girişine takılan uygun fiyatlı HDMI video yakalama kartından canlı kare yakalayıp gerçek zamanlı çeviri.',
      technicalDetails: 'Android UVC Camera API / WebRTC MediaDevices stream capture.'
    },
    {
      id: 'f7',
      title: 'Akıllı Telefon Yardımcı Kamera (Companion Camera)',
      status: 'planned',
      category: 'Sistem Entegrasyonu',
      description: 'Telefon kamerasını TV ekranına doğrultup yerel ağ (Wi-Fi/WebRTC) üzerinden TV\'ye senkronize altyazı gönderme.',
      technicalDetails: 'Yerel WebSocket/WebRTC eşler arası veri kanalı.'
    },
    {
      id: 'f8',
      title: 'HDMI Doğrudan Donanım Katmanı (Bypass)',
      status: 'research',
      category: 'Sistem Entegrasyonu',
      description: 'Konsolun HDMI portunu doğrudan TV işletim sisteminden dinleme araştırması (Teknik ve yasal HDCP engeli mevcuttur).',
      technicalDetails: 'Aşağıdaki teknik analizde detaylandırılmıştır.'
    }
  ];

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      {/* Başlık ve Şeffaflık Taahhüdü */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Şeffaf Mühendislik & Güvenlik Beyanı</span>
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Teknik Mimari, HDCP Sınırları ve Özellik Durumu
        </h1>
        <p className="text-sm text-slate-300 mt-2 leading-relaxed">
          OyunTürkçe projesinde kullanıcılarımızı yanıltıcı vaatlerle aldatmıyoruz. 
          Konsol oyunlarının televizyon üzerindeki işleyişi, donanım şifrelemeleri ve şu anda 
          <strong className="text-white"> gerçekte çalışan</strong> ile 
          <strong className="text-white"> gelecekte planlanan</strong> özellikleri aşağıda açıkça listeliyoruz.
        </p>
      </div>

      {/* Kritik Güvenlik Kuralları Vurgusu */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
            <Lock className="w-4 h-4" />
            <span>Sıfır PSN Kimlik Bilgisi (PlayStation Hesabı İstenmez)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Bu uygulama PlayStation Network (PSN), Xbox Live veya Steam şifrenizi ya da giriş bilgilerinizi
            <strong> ASLA talep etmez</strong>. Uygulama konsol hesabınızdan tamamen bağımsız çalışır ve
            yalnızca ekrandaki pikselleri görsel olarak işler.
          </p>
        </div>

        <div className="p-5 bg-cyan-950/20 border border-cyan-500/30 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
            <Cpu className="w-4 h-4" />
            <span>Sıfır Ücretli API (Tamamen Ücretsiz & On-Device)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Çeviri veya metin tanıma için kredi kartı, ücretli API anahtarı veya aylık abonelik gerekmez.
            Cihaz üzerinde çalışan Tesseract.js kütüphanesi ve açık oyun sözlükleri kullanılır.
          </p>
        </div>
      </div>

      {/* PS5 ve HDMI HDCP Donanım Gerçeği - Dürüst Teknik Açıklama */}
      <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-2.5 text-amber-400 font-bold text-base">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <span>PS5 ve HDMI Girişi Hakkında Gerçekçi Teknik Açıklama</span>
        </div>

        <div className="space-y-3 text-xs md:text-sm text-slate-300 leading-relaxed">
          <p>
            Pek çok kullanıcı "Neden TV'ye kurulan bir uygulama HDMI 1'de oynadığım PS5 oyununun üzerine doğrudan altyazı bindiremiyor?" 
            diye sormaktadır. Bunun net ve kesin iki teknik nedeni vardır:
          </p>

          <ol className="list-decimal pl-5 space-y-2 text-slate-300">
            <li>
              <strong className="text-white">HDCP (High-Bandwidth Digital Content Protection) Şifrelemesi:</strong>
              PlayStation 5, Xbox Series X ve Nintendo Switch gibi tüm modern oyun konsolları, HDMI kablosu üzerinden video aktarırken 
              donanımsal HDCP şifrelemesi kullanır. Bu şifreleme korsanlığı önlemek amacıyla geliştirilmiş uluslararası bir standarttır.
            </li>
            <li>
              <strong className="text-white">Android TV İşletim Sistemi İzolasyonu:</strong>
              Android TV / Google TV mimarisinde, televizyonun harici HDMI girişleri (HDMI 1, HDMI 2 vb.) doğrudan donanım video işleyicisine 
              (Hardware Video Pipeline) bağlıdır. İşletim sistemi güvenlik ilkeleri gereği, arka planda çalışan üçüncü taraf bir APK uygulamasının 
              HDMI portundaki korumalı pikselleri gizlice kaydetmesine veya üzerine çizim (overlay) yapmasına izin verilmez.
            </li>
          </ol>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 mt-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Bu Sınırı Aşmanın 4 Gerçekçi ve Test Edilmiş Yolu:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <div className="font-bold text-emerald-400 mb-1">
                  1. Fotoğraf / Anlık Görüntü (Şu Anki Prototipimiz)
                </div>
                <p className="text-slate-400 text-[11px]">
                  TV ekranından çekilen fotoğraf veya kaydedilen oyun karesi uygulamaya verilir. 
                  Yapay zeka altyazıyı saniyeler içinde okuyup Türkçe'ye çevirir. Hiçbir ek donanım gerektirmez.
                </p>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <div className="font-bold text-amber-400 mb-1">
                  2. USB Video Yakalama Kartı (UVC - Planlanan)
                </div>
                <p className="text-slate-400 text-[11px]">
                  Konsol ile TV arasına takılan 10-15 dolarlık USB HDMI capture card, videoyu Android TV'ye standart bir 
                  web kamerası (UVC) gibi sunar ve canlı altyazı taramasını mümkün kılar.
                </p>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <div className="font-bold text-sky-400 mb-1">
                  3. Telefon Kamera Senkronizasyonu (Planlanan)
                </div>
                <p className="text-slate-400 text-[11px]">
                  Oturma odasında bir sehpaya koyulan telefon kamerası TV altyazılarını canlı okur ve 
                  aynı Wi-Fi ağındaki Android TV ekranına altyazı balonu olarak fırlatır.
                </p>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <div className="font-bold text-purple-400 mb-1">
                  4. PS Remote Play / Ekran Paylaşımı
                </div>
                <p className="text-slate-400 text-[11px]">
                  Konsol yayını yerel ağ üzerinden Android TV'deki bir istemciye aktarıldığında, 
                  yazılım doğrudan piksellere erişebilir ve altyazıyı dinamik olarak çevirebilir.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Özellik Matrisi: Çalışan vs Planlanan */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight">
            Özellik Matrisi & Yol Haritası
          </h2>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Aktif & Çalışan</span>
            </span>
            <span className="flex items-center gap-1.5 text-amber-400">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>Planlanan</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.map((item) => {
            const isActive = item.status === 'active';
            return (
              <div
                key={item.id}
                className={`p-4 rounded-xl border transition-all ${
                  isActive
                    ? 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    : 'bg-slate-950/60 border-slate-900 opacity-90'
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="font-semibold text-sm text-white">{item.title}</div>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                      isActive
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {isActive ? 'Çalışıyor' : 'Planlanan'}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mb-2">
                  {item.description}
                </p>
                <div className="text-[11px] font-mono text-slate-500 border-t border-slate-800/80 pt-2">
                  Teknik Altyapı: {item.technicalDetails}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
