import React from 'react';
import { TvSettings } from '../types';
import { Volume2 } from 'lucide-react';

interface TvSubtitleOverlayProps {
  originalText: string;
  translatedText: string;
  speaker?: string;
  settings: TvSettings;
  onSpeak: (text: string, lang: 'tr' | 'en') => void;
  showOriginal: boolean;
}

export const TvSubtitleOverlay: React.FC<TvSubtitleOverlayProps> = ({
  originalText,
  translatedText,
  speaker,
  settings,
  onSpeak,
  showOriginal,
}) => {
  if (!translatedText && !originalText) {
    return null;
  }

  // Boyut sınıfı seçimi (Koltuk mesafesinden okunabilirlik)
  const sizeClasses = {
    small: 'text-base md:text-lg',
    medium: 'text-lg md:text-xl',
    large: 'text-xl md:text-2xl font-semibold',
    'extra-large': 'text-2xl md:text-3xl font-bold tracking-wide'
  }[settings.fontSize];

  // Renk seçimi (Oyun altyazıları için sarı, beyaz vb.)
  const colorClasses = {
    yellow: 'text-amber-300',
    white: 'text-white',
    cyan: 'text-cyan-300',
    green: 'text-emerald-300'
  }[settings.textColor];

  const shadowClass = settings.textShadow
    ? '[text-shadow:_0_2px_4px_rgb(0_0_0_/_90%),_0_4px_12px_rgb(0_0_0_/_80%)]'
    : '';

  const bgStyle = {
    backgroundColor: `rgba(15, 23, 42, ${settings.bgOpacity / 100})`
  };

  return (
    <div className="w-full flex justify-center pointer-events-auto">
      <div
        style={bgStyle}
        className={`max-w-4xl mx-auto px-6 py-3.5 rounded-xl border border-slate-700/50 backdrop-blur-sm transition-all duration-200 text-center ${shadowClass}`}
      >
        {/* Konuşmacı başlığı (Varsa) */}
        {speaker && (
          <div className="text-xs uppercase tracking-wider text-cyan-400 font-bold mb-1">
            {speaker}
          </div>
        )}

        {/* Ana Türkçe Çeviri Altyazısı */}
        <div className={`leading-relaxed ${sizeClasses} ${colorClasses} font-sans`}>
          {translatedText || 'Çeviri bekleniyor...'}
        </div>

        {/* İsteğe bağlı orijinal İngilizce altyazı (İki dilli mod) */}
        {showOriginal && originalText && (
          <div className="mt-1.5 text-xs md:text-sm text-slate-400 italic font-mono border-t border-slate-800/80 pt-1.5 flex items-center justify-center gap-2">
            <span>ENG: {originalText}</span>
            <button
              onClick={() => onSpeak(originalText, 'en')}
              className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="İngilizce Telaffuz Dinle"
            >
              <Volume2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
