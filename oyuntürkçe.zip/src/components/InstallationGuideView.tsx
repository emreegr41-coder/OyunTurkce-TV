import React, { useState } from 'react';
import {
  Download,
  Usb,
  Wifi,
  ShieldAlert,
  CheckCircle,
  Copy,
  ChevronRight,
  Tv,
  HelpCircle,
  Layers
} from 'lucide-react';
import { soundEffects } from '../utils/soundEffects';

export const InstallationGuideView: React.FC = () => {
  const [selectedMethod, setSelectedMethod] = useState<'downloader' | 'usb' | 'adb'>('downloader');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (text: string) => {
    soundEffects.playSuccess();
    navigator.clipboard.writeText(text);
    setCopiedCode(text);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Başlık Kartı */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-2">
          <Tv className="w-4 h-4" />
          <span>Android TV / Google TV Kurulum Kılavuzu</span>
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">
          OyunTürkçe APK Dosyasını Televizyonunuza Yükleme
        </h1>
        <p className="text-sm text-slate-300 mt-2 leading-relaxed">
          OyunTürkçe, Android TV standartlarına uygun olarak tasarlanmıştır. Televizyonunuza yüklemek (sideload) için
          aşağıdaki 3 pratik yöntemden birini seçebilirsiniz.
        </p>
      </div>

      {/* Yöntem Seçim Sekmeleri */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => {
            soundEffects.playSelect();
            setSelectedMethod('downloader');
          }}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedMethod === 'downloader'
              ? 'bg-slate-800 border-cyan-400 ring-2 ring-cyan-400/40 shadow-lg'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          } focus:outline-none focus:ring-2 focus:ring-amber-400`}
        >
          <div className="w-9 h-9 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-2.5">
            <Download className="w-5 h-5" />
          </div>
          <div className="font-bold text-sm text-white">1. Downloader ile Yükleme</div>
          <div className="text-xs text-slate-400 mt-1">
            En kolay yol: TV'deki web tarayıcı aracıyla doğrudan indirme
          </div>
        </button>

        <button
          onClick={() => {
            soundEffects.playSelect();
            setSelectedMethod('usb');
          }}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedMethod === 'usb'
              ? 'bg-slate-800 border-cyan-400 ring-2 ring-cyan-400/40 shadow-lg'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          } focus:outline-none focus:ring-2 focus:ring-amber-400`}
        >
          <div className="w-9 h-9 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2.5">
            <Usb className="w-5 h-5" />
          </div>
          <div className="font-bold text-sm text-white">2. USB Flash Bellek ile</div>
          <div className="text-xs text-slate-400 mt-1">
            Bilgisayardan APK dosyasını belleğe kopyalayıp TV'ye takma
          </div>
        </button>

        <button
          onClick={() => {
            soundEffects.playSelect();
            setSelectedMethod('adb');
          }}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedMethod === 'adb'
              ? 'bg-slate-800 border-cyan-400 ring-2 ring-cyan-400/40 shadow-lg'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          } focus:outline-none focus:ring-2 focus:ring-amber-400`}
        >
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2.5">
            <Wifi className="w-5 h-5" />
          </div>
          <div className="font-bold text-sm text-white">3. Kablosuz ADB ile</div>
          <div className="text-xs text-slate-400 mt-1">
            Wi-Fi üzerinden bilgisayar terminali ile tek satırda yükleme
          </div>
        </button>
      </div>

      {/* Yöntem Detayı */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-6">
        {selectedMethod === 'downloader' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-base">
              <Download className="w-5 h-5" />
              <span>Yöntem 1: "Downloader by AFTVnews" Uygulaması ile İndirme</span>
            </div>

            <ol className="space-y-4 text-xs md:text-sm text-slate-300">
              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-white">Downloader Uygulamasını Yükleyin:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Android TV veya Google TV'nizde Google Play Store'u açın. Arama kısmına <strong>"Downloader"</strong> yazın ve AFTVnews tarafından geliştirilen turuncu simgeli uygulamayı TV'nize kurun.
                  </p>
                </div>
              </li>

              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-white">Bilinmeyen Kaynaklara İzin Verin:</strong>
                  <p className="text-slate-400 mt-0.5">
                    TV Ayarları &gt; Uygulamalar &gt; Güvenlik ve Kısıtlamalar &gt; <strong>Bilinmeyen Uygulamaları Yükle</strong> bölümüne gidin ve <strong>Downloader</strong> için izni açık (Etkin) yapın.
                  </p>
                </div>
              </li>

              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-white">APK Bağlantısını Girin:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Downloader uygulamasını açın ve URL kutucuğuna derlediğiniz veya yayınladığınız APK dosya linkini girin. "Go" tuşuna basın, indirme tamamlandığında <strong>"Yükle" (Install)</strong> butonuna tıklayın.
                  </p>
                </div>
              </li>
            </ol>
          </div>
        )}

        {selectedMethod === 'usb' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
              <Usb className="w-5 h-5" />
              <span>Yöntem 2: USB Bellek (Flash Disk) ile Çevrimdışı Kurulum</span>
            </div>

            <ol className="space-y-4 text-xs md:text-sm text-slate-300">
              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-white">APK Dosyasını USB Belleğe Kopyalayın:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Bilgisayarınızda ürettiğiniz <code className="text-cyan-300 font-mono">OyunTurkce-release.apk</code> dosyasını FAT32 veya exFAT formatlı bir USB flash belleğin kök dizinine atın.
                  </p>
                </div>
              </li>

              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-white">TV'de Dosya Yöneticisi Açın:</strong>
                  <p className="text-slate-400 mt-0.5">
                    USB belleği televizyonun USB girişine takın. TV Play Store'dan ücretsiz <strong>"X-plore File Manager"</strong> veya <strong>"FX File Explorer"</strong> indirin.
                  </p>
                </div>
              </li>

              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-white">APK'yı Çalıştırın ve Kurun:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Dosya yöneticisinden USB belleği seçip <code className="text-cyan-300 font-mono">OyunTurkce.apk</code> dosyasına TV kumandasının <strong>OK</strong> tuşuyla basın. "Yükle"yi onaylayın.
                  </p>
                </div>
              </li>
            </ol>
          </div>
        )}

        {selectedMethod === 'adb' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-base">
              <Wifi className="w-5 h-5" />
              <span>Yöntem 3: Kablosuz ADB (Android Debug Bridge) ile Yükleme</span>
            </div>

            <p className="text-xs text-slate-300">
              Geliştiriciler ve kablosuz hızlı yükleme yapmak isteyenler için en temiz yöntemdir:
            </p>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-500"># 1. Televizyonun IP adresine bağlanın (Aynı Wi-Fi):</span>
                  <div className="text-cyan-300 font-bold mt-1">adb connect 192.168.1.150:5555</div>
                </div>
                <button
                  onClick={() => handleCopy('adb connect 192.168.1.150:5555')}
                  className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                  title="Komutu Kopyala"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-500"># 2. APK'yı televizyona kurun:</span>
                  <div className="text-emerald-300 font-bold mt-1">adb install -r OyunTurkce.apk</div>
                </div>
                <button
                  onClick={() => handleCopy('adb install -r OyunTurkce.apk')}
                  className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                  title="Komutu Kopyala"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Android TV Leanback Banner Önizlemesi */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-1">
          Android TV Ana Ekran Afişi (Leanback Banner)
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Android TV ana ekranında ve "Uygulamalar" (Apps) satırında standart 16:9 (320x180 px veya 1920x1080 px) afiş kullanılır:
        </p>

        <div className="aspect-video max-w-md mx-auto rounded-xl overflow-hidden border border-slate-700 shadow-xl bg-black">
          <img
            src="/src/assets/images/android_tv_banner_1792872227445.jpg"
            alt="OyunTürkçe Android TV Banner"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </div>
  );
};
