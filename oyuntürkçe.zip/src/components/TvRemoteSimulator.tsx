import React from 'react';
import {
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Undo2,
  Volume2,
  VolumeX,
  X,
  Type,
  Maximize2
} from 'lucide-react';
import { soundEffects } from '../utils/soundEffects';

interface TvRemoteSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  onDpadMove: (direction: 'up' | 'down' | 'left' | 'right') => void;
  onSelect: () => void;
  onBack: () => void;
  onToggleMute: () => void;
  isMuted: boolean;
  onCycleFontSize: () => void;
}

export const TvRemoteSimulator: React.FC<TvRemoteSimulatorProps> = ({
  isOpen,
  onClose,
  onDpadMove,
  onSelect,
  onBack,
  onToggleMute,
  isMuted,
  onCycleFontSize
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 w-72 bg-slate-900/95 border border-slate-700/80 rounded-2xl p-4 shadow-2xl backdrop-blur-md text-slate-100 animate-in fade-in slide-in-from-bottom-4 duration-200">
      {/* Remote header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Android TV Kumandası
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={onToggleMute}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title={isMuted ? 'Sesi Aç' : 'Sesi Kapat'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Kapat"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <p className="text-[11px] text-slate-400 mt-2 mb-3 leading-relaxed">
        Klavye ok tuşları <kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">↑</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">↓</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">←</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">→</kbd>, <kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">Enter</kbd> ve <kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">Esc</kbd> ile de çalışır.
      </p>

      {/* D-Pad Circular Joystick Container */}
      <div className="relative my-3 flex items-center justify-center">
        <div className="w-44 h-44 rounded-full bg-slate-950 border border-slate-700/70 p-2 shadow-inner relative flex items-center justify-center">
          {/* UP button */}
          <button
            onClick={() => {
              soundEffects.playFocusMove();
              onDpadMove('up');
            }}
            className="absolute top-2 w-12 h-10 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all bg-slate-800/80 hover:bg-slate-700 rounded-t-xl cursor-pointer"
            title="Yukarı (D-Pad UP)"
          >
            <ChevronUp className="w-6 h-6" />
          </button>

          {/* DOWN button */}
          <button
            onClick={() => {
              soundEffects.playFocusMove();
              onDpadMove('down');
            }}
            className="absolute bottom-2 w-12 h-10 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all bg-slate-800/80 hover:bg-slate-700 rounded-b-xl cursor-pointer"
            title="Aşağı (D-Pad DOWN)"
          >
            <ChevronDown className="w-6 h-6" />
          </button>

          {/* LEFT button */}
          <button
            onClick={() => {
              soundEffects.playFocusMove();
              onDpadMove('left');
            }}
            className="absolute left-2 w-10 h-12 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all bg-slate-800/80 hover:bg-slate-700 rounded-l-xl cursor-pointer"
            title="Sol (D-Pad LEFT)"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* RIGHT button */}
          <button
            onClick={() => {
              soundEffects.playFocusMove();
              onDpadMove('right');
            }}
            className="absolute right-2 w-10 h-12 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all bg-slate-800/80 hover:bg-slate-700 rounded-r-xl cursor-pointer"
            title="Sağ (D-Pad RIGHT)"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* CENTER OK / SELECT button */}
          <button
            onClick={() => {
              soundEffects.playSelect();
              onSelect();
            }}
            className="w-16 h-16 rounded-full bg-cyan-600 hover:bg-cyan-500 active:scale-90 text-white font-bold text-xs tracking-wider shadow-lg shadow-cyan-600/30 flex items-center justify-center transition-all cursor-pointer border border-cyan-400/40"
            title="Tamam / Seç (D-Pad CENTER)"
          >
            OK
          </button>
        </div>
      </div>

      {/* Auxiliary TV Action Buttons */}
      <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800">
        <button
          onClick={() => {
            soundEffects.playFocusMove();
            onBack();
          }}
          className="flex flex-col items-center justify-center gap-1 py-2 px-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg text-slate-300 hover:text-white transition-all text-[10px] cursor-pointer"
          title="Geri (Back)"
        >
          <Undo2 className="w-4 h-4 text-amber-400" />
          <span>Geri</span>
        </button>

        <button
          onClick={() => {
            soundEffects.playFocusMove();
            onCycleFontSize();
          }}
          className="flex flex-col items-center justify-center gap-1 py-2 px-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg text-slate-300 hover:text-white transition-all text-[10px] cursor-pointer"
          title="Yazı Boyutu Değiştir"
        >
          <Type className="w-4 h-4 text-cyan-400" />
          <span>Boyut</span>
        </button>

        <button
          onClick={() => {
            soundEffects.playSelect();
            const elem = document.documentElement;
            if (!document.fullscreenElement) {
              elem.requestFullscreen?.().catch(() => {});
            } else {
              document.exitFullscreen?.().catch(() => {});
            }
          }}
          className="flex flex-col items-center justify-center gap-1 py-2 px-1 bg-slate-800 hover:bg-slate-700 active:scale-95 rounded-lg text-slate-300 hover:text-white transition-all text-[10px] cursor-pointer"
          title="Tam Ekran TV Modu"
        >
          <Maximize2 className="w-4 h-4 text-emerald-400" />
          <span>Tam Ekran</span>
        </button>
      </div>
    </div>
  );
};
