import React from 'react';
import { TvSettings } from '../types';
import { soundEffects } from '../utils/soundEffects';
import {
  Type,
  Palette,
  Eye,
  Volume2,
  Tv,
  Check,
  RotateCcw
} from 'lucide-react';

interface SettingsViewProps {
  settings: TvSettings;
  onUpdateSettings: (newSettings: Partial<TvSettings>) => void;
  onResetSettings: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onResetSettings,
}) => {
  const fontSizes: { id: TvSettings['fontSize']; label: string; desc: string }[] = [
    { id: 'small', label: 'Küçük', desc: 'Monitör / Yakın mesafe (16-18px)' },
    { id: 'medium', label: 'Normal', desc: 'Standart TV mesafesi (18-20px)' },
    { id: 'large', label: 'Büyük', desc: '2-3 metre koltuk mesafesi (22-24px)' },
    { id: 'extra-large', label: 'Dev', desc: 'Geniş ekran 4K salon TV (28-32px)' }
  ];

  const colors: { id: TvSettings['textColor']; label: string; hex: string }[] = [
    { id: 'yellow', label: 'Oyun Sarısı (Önerilen)', hex: '#fde047' },
    { id: 'white', label: 'Saf Beyaz', hex: '#ffffff' },
    { id: 'cyan', label: 'Siber Camgöbeği', hex: '#67e8f9' },
    { id: 'green', label: 'Matriks Yeşili', hex: '#86efac' }
  ];

  const opacities = [0, 40, 75, 100];

  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-12">
      {/* Başlık */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex items-center justify-between">
        <div>
          <div className="text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-1">
            Android TV Ekran & Ses Tercihleri
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Altyazı Görünümü ve TV Ayarları
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Koltuk mesafenize ve televizyon boyutunuza göre altyazı renk, boyut ve ses ayarlarını özelleştirin.
          </p>
        </div>
        <button
          onClick={() => {
            soundEffects.playSelect();
            onResetSettings();
          }}
          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Varsayılana Sıfırla</span>
        </button>
      </div>

      {/* Altyazı Yazı Boyutu */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <Type className="w-4 h-4 text-cyan-400" />
          <span>Altyazı Yazı Boyutu (TV Koltuk Mesafesi İçin)</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {fontSizes.map((f) => {
            const isSelected = settings.fontSize === f.id;
            return (
              <button
                key={f.id}
                onClick={() => {
                  soundEffects.playSelect();
                  onUpdateSettings({ fontSize: f.id });
                }}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-800 border-cyan-400 ring-2 ring-cyan-400/40 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/50'
                } focus:outline-none focus:ring-2 focus:ring-amber-400`}
              >
                <div className="font-bold text-xs flex items-center justify-between">
                  <span>{f.label}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                </div>
                <div className="text-[10px] text-slate-400 mt-1">{f.desc}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Altyazı Rengi */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <Palette className="w-4 h-4 text-amber-400" />
          <span>Altyazı Metin Rengi</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {colors.map((c) => {
            const isSelected = settings.textColor === c.id;
            return (
              <button
                key={c.id}
                onClick={() => {
                  soundEffects.playSelect();
                  onUpdateSettings({ textColor: c.id });
                }}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2.5 ${
                  isSelected
                    ? 'bg-slate-800 border-cyan-400 ring-2 ring-cyan-400/40 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/50'
                } focus:outline-none focus:ring-2 focus:ring-amber-400`}
              >
                <span
                  className="w-4 h-4 rounded-full border border-slate-700 shrink-0 shadow-sm"
                  style={{ backgroundColor: c.hex }}
                />
                <span className="font-semibold text-xs">{c.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Arka Plan Şerit Opaklığı */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <Eye className="w-4 h-4 text-emerald-400" />
          <span>Altyazı Arka Plan Opaklığı</span>
        </div>

        <div className="grid grid-cols-4 gap-3">
          {opacities.map((op) => {
            const isSelected = settings.bgOpacity === op;
            return (
              <button
                key={op}
                onClick={() => {
                  soundEffects.playSelect();
                  onUpdateSettings({ bgOpacity: op });
                }}
                className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-800 border-cyan-400 ring-2 ring-cyan-400/40 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/50'
                } focus:outline-none focus:ring-2 focus:ring-amber-400`}
              >
                <div className="font-bold text-xs">%{op}</div>
                <div className="text-[10px] text-slate-400">
                  {op === 0 ? 'Şeffaf' : op === 75 ? 'Önerilen' : op === 100 ? 'Siyah Kutu' : 'Hafif'}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Ses ve Seslendirme Ayarları */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <Volume2 className="w-4 h-4 text-cyan-400" />
          <span>Ses ve Kumanda Geri Bildirimi</span>
        </div>

        <div className="space-y-3">
          <label className="flex items-center justify-between p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl cursor-pointer">
            <div>
              <div className="text-xs font-semibold text-white">
                TV Kumanda D-Pad Ses Efektleri
              </div>
              <div className="text-[11px] text-slate-400">
                Kumanda yön tuşlarına basıldığında hafif tık sesi çalar.
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.soundEffects}
              onChange={(e) => {
                soundEffects.setEnabled(e.target.checked);
                onUpdateSettings({ soundEffects: e.target.checked });
              }}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl cursor-pointer">
            <div>
              <div className="text-xs font-semibold text-white">
                Otomatik Türkçe Seslendirme (TTS)
              </div>
              <div className="text-[11px] text-slate-400">
                Altyazı çevirisi bittiğinde cümleyi TV hoparlöründen sesli okur.
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.autoSpeak}
              onChange={(e) => onUpdateSettings({ autoSpeak: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
