import React, { useState } from 'react';
import {
  FileCode2,
  Copy,
  Check,
  Download,
  Terminal,
  FolderTree,
  Smartphone,
  Server,
  Cpu,
  Layers,
  HelpCircle,
  ExternalLink,
  Archive,
  ArrowRight
} from 'lucide-react';
import { ANDROID_STUDIO_FILES } from '../data/androidProjectFiles';
import { downloadSingleFile, downloadFullProjectZip, downloadStaticFileAsBlob } from '../utils/projectDownloader';
import { soundEffects } from '../utils/soundEffects';

export const SourceCodeApkView: React.FC = () => {
  const [selectedFileKey, setSelectedFileKey] = useState<string>('manifest');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [zipProgress, setZipProgress] = useState<number>(0);
  const [activeSubTab, setActiveSubTab] = useState<'files' | 'phone_build' | 'build_steps'>('files');

  const selectedFile = ANDROID_STUDIO_FILES[selectedFileKey] || ANDROID_STUDIO_FILES.manifest;

  const handleCopy = (key: string, content: string) => {
    soundEffects.playSuccess();
    navigator.clipboard.writeText(content);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownloadSingle = () => {
    soundEffects.playSuccess();
    downloadSingleFile(selectedFile.name, selectedFile.content);
  };

  const handleDownloadZip = async () => {
    soundEffects.playSelect();
    setIsZipping(true);
    setZipProgress(10);
    try {
      await downloadFullProjectZip((progress) => {
        setZipProgress(progress);
      });
      soundEffects.playSuccess();
    } catch (err) {
      console.error('ZIP oluşturma hatası:', err);
    } finally {
      setIsZipping(false);
      setZipProgress(0);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      {/* Üst Başlık & Hızlı İndirme Eylemleri */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-1.5">
            <Terminal className="w-4 h-4" />
            <span>Eksiksiz Android Studio TV Proje Dosyaları</span>
            <span className="text-slate-500">·</span>
            <span>Android TV & Google TV Uyumlu</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Android Studio Proje Dosyaları & APK Derleme
          </h1>
          <p className="text-xs md:text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
            Android TV standartlarına (<code className="text-cyan-300 font-mono">touchscreen=false</code>, <code className="text-cyan-300 font-mono">LEANBACK_LAUNCHER</code>) tam uyumlu dosya seti.
            Dosyaları tek tek veya klasör yapısıyla tek bir <strong>.ZIP paketi</strong> olarak indirebilirsiniz.
          </p>
        </div>

        {/* Tüm Projeyi ZIP İndir Düğmesi (Tarayıcı İçi Güvenli Blob İndirme) */}
        <div className="flex flex-col items-end gap-2 w-full md:w-auto">
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="w-full md:w-auto px-6 py-3.5 bg-cyan-500 hover:bg-cyan-400 active:scale-95 disabled:opacity-50 text-slate-950 font-bold rounded-xl shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2.5 transition-all cursor-pointer whitespace-nowrap focus:outline-none focus:ring-4 focus:ring-amber-400 text-sm"
          >
            {isZipping ? (
              <>
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>Paketleniyor (%{zipProgress})...</span>
              </>
            ) : (
              <>
                <Archive className="w-5 h-5" />
                <span>Tüm Projeyi ZIP Olarak İndir (İndirmeyi Başlat)</span>
              </>
            )}
          </button>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>Tarayıcıdan Doğrudan İndirme</span>
            </span>
          </div>
        </div>
      </div>

      {/* Dürüst Bildirim ve Şeffaflık Kutusu */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-5 space-y-2 text-xs md:text-sm text-slate-200 leading-relaxed">
        <div className="flex items-center gap-2 text-amber-400 font-bold">
          <HelpCircle className="w-5 h-5 shrink-0" />
          <span>Doğrudan APK Derleme Hakkında Dürüst Açıklama</span>
        </div>
        <p>
          Bu web geliştirme konteynerinde Android SDK, Java ve Gradle derleme araçları yüklü olmadığından, 
          doğrudan ikili (binary) <code className="text-amber-300 font-mono">.apk</code> dosyası bu pencere içinde 
          fiziksel olarak derlenemez. 
          Buna karşılık, projenin <strong>tüm Android Studio kodları eksiksiz hazırlanmıştır</strong>. 
          Aşağıdaki rehber ile <strong>Android telefonunuzu kullanarak 1 dakikada tamamen ücretsiz</strong> gerçek bir TV APK'sı üretebilirsiniz.
        </p>
      </div>

      {/* Alt Gezinme Sekmeleri (Görünüm Seçici) */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto">
        <button
          onClick={() => {
            soundEffects.playSelect();
            setActiveSubTab('phone_build');
          }}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
            activeSubTab === 'phone_build'
              ? 'bg-amber-400/20 text-amber-300 border border-amber-400/50 shadow-md'
              : 'text-slate-300 hover:text-white hover:bg-slate-900 border border-transparent'
          }`}
        >
          <Smartphone className="w-4 h-4 text-amber-400" />
          <span>Telefondan 1 Dakikada APK Üret (En Kolay Yol)</span>
        </button>

        <button
          onClick={() => {
            soundEffects.playSelect();
            setActiveSubTab('files');
          }}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
            activeSubTab === 'files'
              ? 'bg-slate-800 text-white border border-slate-700 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
          }`}
        >
          Proje Dosyaları ({Object.keys(ANDROID_STUDIO_FILES).length} Adet)
        </button>

        <button
          onClick={() => {
            soundEffects.playSelect();
            setActiveSubTab('build_steps');
          }}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
            activeSubTab === 'build_steps'
              ? 'bg-slate-800 text-white border border-slate-700 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
          }`}
        >
          Android Studio / Gradle ile Derleme
        </button>
      </div>

      {/* 1. SEKMELİ DOSYA GEZGİNİ VE TEK TEK İNDİRME */}
      {activeSubTab === 'files' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Sol Kolon: Dosya Listesi (TV Focus uyumlu) */}
          <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <FolderTree className="w-4 h-4 text-cyan-400" />
                <span>Dosya Gezgini</span>
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                {Object.keys(ANDROID_STUDIO_FILES).length} adet
              </span>
            </div>

            <div className="space-y-1.5 max-h-[540px] overflow-y-auto pr-1">
              {Object.entries(ANDROID_STUDIO_FILES).map(([key, f]) => {
                const isSelected = selectedFileKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => {
                      soundEffects.playSelect();
                      setSelectedFileKey(key);
                    }}
                    className={`w-full text-left p-3 rounded-xl transition-all cursor-pointer flex flex-col ${
                      isSelected
                        ? 'bg-cyan-500/10 border border-cyan-400/50 text-cyan-300 shadow-md'
                        : 'bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-800/50'
                    } focus:outline-none focus:ring-2 focus:ring-amber-400`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-mono text-xs font-bold truncate flex items-center gap-1.5">
                        <FileCode2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        {f.name}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 font-mono text-slate-400 uppercase">
                        {f.category}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono truncate mt-1">
                      {f.path}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sağ Kolon: Seçili Dosya İnceleme & Tekil İndir Düğmesi */}
          <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden flex flex-col">
            {/* Dosya Başlık Şeridi */}
            <div className="bg-slate-900/90 border-b border-slate-800 px-5 py-3 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs font-mono font-bold text-white flex items-center gap-2">
                  <span>{selectedFile.path}</span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    ({selectedFile.lang.toUpperCase()})
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {selectedFile.description}
                </div>
              </div>

              {/* Kopyala ve İndir Butonları */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(selectedFile.id, selectedFile.content)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Metni Kopyala"
                >
                  {copiedKey === selectedFile.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Kopyalandı</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Kopyala</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleDownloadSingle}
                  className="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                  title="Bu Dosyayı Tek Olarak İndir"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Dosyayı İndir</span>
                </button>
              </div>
            </div>

            {/* Kod Metni */}
            <div className="p-4 overflow-x-auto text-xs font-mono text-slate-300 leading-relaxed max-h-[500px] select-text">
              <pre className="whitespace-pre">{selectedFile.content}</pre>
            </div>
          </div>
        </div>
      )}

      {/* 2. ANDROİD TELEFONDAN APK OLUŞTURMA REHBERİ (DETAYLI ANALİZ) */}
      {activeSubTab === 'phone_build' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-6 space-y-3">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
              <Smartphone className="w-5 h-5" />
              <span>Android Telefondan Bilgisayarsız APK Oluşturmak Mümkün mü?</span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed">
              <strong>Evet, mümkündür.</strong> Ancak Android telefonun donanımına, işletim sisteminin izinlerine ve seçilen yönteme göre 
              farklı teknik kolaylıklar veya zorluklar vardır. Aşağıdaki 3 yöntemi inceleyin:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Yöntem A: GitHub Actions (Önerilen) */}
            <div className="p-5 bg-slate-900/80 border border-emerald-500/30 rounded-2xl space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                    1. Yöntem (En Kolay & Önerilen)
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 font-bold">
                    %100 Çalışır
                  </span>
                </div>
                <h3 className="font-bold text-base text-white">GitHub Actions Bulut Derleme</h3>
                <p className="text-xs text-slate-300 leading-relaxed mt-2">
                  Telefonunuzun tarayıcısından ücretsiz bir GitHub hesabı açıp proje dosyalarını yüklersiniz. 
                  GitHub sunucuları projeyi ücretsiz derler ve üretilen <code className="text-cyan-300 font-mono">app-release.apk</code> dosyasını doğrudan telefonunuza indirir.
                </p>
                <div className="mt-3 p-3 bg-slate-950 rounded-xl text-[11px] text-slate-400 space-y-1">
                  <div>✓ Telefonda RAM veya depolama tüketmez.</div>
                  <div>✓ Android Studio veya Java kurmaya gerek yoktur.</div>
                  <div>✓ 3 dakika içinde hazır kurulabilir APK verir.</div>
                </div>
              </div>
            </div>

            {/* Yöntem B: PWA to WebAPK */}
            <div className="p-5 bg-slate-900/80 border border-cyan-500/30 rounded-2xl space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                    2. Yöntem (Telefonda En Hızlı)
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 font-bold">
                    1 Dakika
                  </span>
                </div>
                <h3 className="font-bold text-base text-white">PWABuilder ile Doğrudan APK</h3>
                <p className="text-xs text-slate-300 leading-relaxed mt-2">
                  Uygulamanın canlı linkini Microsoft'un resmi ve ücretsiz <strong>PWABuilder (pwabuilder.com)</strong> servisine girerek telefonunuzdan anında Android TV APK'sı indirebilirsiniz.
                </p>
                <div className="mt-3 p-3 bg-slate-950 rounded-xl text-[11px] text-slate-300 space-y-1.5">
                  <div className="flex items-center justify-between text-slate-400 pb-1 border-b border-slate-800">
                    <span>Mevcut Uygulama Linkiniz:</span>
                    <button
                      onClick={() => handleCopy('app-url', window.location.href)}
                      className="text-cyan-400 hover:text-white font-bold cursor-pointer text-[10px]"
                    >
                      {copiedKey === 'app-url' ? 'Kopyalandı!' : 'Linki Kopyala'}
                    </button>
                  </div>
                  <div>1. Yukarıdaki linki kopyalayın.</div>
                  <div>2. <a href="https://www.pwabuilder.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">pwabuilder.com</a> adresini telefondan açıp yapıştırın.</div>
                  <div>3. <strong>"Package for Android"</strong> butonuna basıp APK'yı indirin.</div>
                  <div>4. <strong>"Send Files to TV"</strong> uygulamasıyla APK'yı TV'ye gönderip kurun!</div>
                </div>
              </div>
            </div>

            {/* Yöntem C: Termux (Telefonda Yerel Derleme) */}
            <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    3. Yöntem (İleri Düzey)
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 font-bold">
                    Zor & Ağır
                  </span>
                </div>
                <h3 className="font-bold text-base text-white">Termux + OpenJDK ile Telefonda</h3>
                <p className="text-xs text-slate-300 leading-relaxed mt-2">
                  Telefona Termux Linux terminali ve Android SDK kurulur. Telefonda <code className="text-amber-300 font-mono">./gradlew assembleDebug</code> çalıştırılır.
                </p>
                <div className="mt-3 p-3 bg-slate-950 rounded-xl text-[11px] text-slate-400 space-y-1">
                  <div>⚠️ Telefonda 4-6 GB boş hafıza ve 6GB+ RAM gerektirir.</div>
                  <div>⚠️ Pil tüketimi ve ısınma çok yüksektir.</div>
                  <div>⚠️ ARM64 ikili uyumsuzlukları sık yaşanır.</div>
                </div>
              </div>
            </div>
          </div>

          {/* GitHub Actions YAML Örneği */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Telefondan Tek Tıkla APK Üreten GitHub Actions İş Akışı (.github/workflows/build.yml)
              </span>
              <button
                onClick={() =>
                  handleCopy(
                    'gh-workflow',
                    `name: Android TV APK Derle
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: JDK 17 Kur
        uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: APK Derle
        run: ./gradlew assembleRelease
      - name: APK Dosyasını Yayınla
        uses: actions/upload-artifact@v4
        with:
          name: OyunTurkce-TV-APK
          path: app/build/outputs/apk/release/*.apk`
                  )
                }
                className="text-xs text-cyan-400 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'gh-workflow' ? 'Kopyalandı' : 'Workflow Kopyala'}
              </button>
            </div>
            <pre className="p-3 bg-slate-900 rounded-xl text-slate-300 font-mono text-[11px] overflow-x-auto">
{`name: Android TV APK Derle
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: JDK 17 Kur
        uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: APK Derle
        run: ./gradlew assembleRelease
      - name: APK Dosyasını Yayınla
        uses: actions/upload-artifact@v4
        with:
          name: OyunTurkce-TV-APK
          path: app/build/outputs/apk/release/*.apk`}
            </pre>
          </div>
        </div>
      )}

      {/* 3. BİLGİSAYARDA DERLEME ADIMLARI */}
      {activeSubTab === 'build_steps' && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-400">
              Android Studio Arayüzü ile Adım Adım APK Oluşturma
            </h3>
            <ol className="space-y-3 text-xs md:text-sm text-slate-300">
              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0">
                  1
                </span>
                <div>
                  <strong className="text-white">ZIP Dosyasını İndirin ve Açın:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Sayfanın üstündeki "Tüm Projeyi ZIP Olarak İndir" butonuna tıklayın ve indirilen klasörü bilgisayarınızda çıkartın.
                  </p>
                </div>
              </li>

              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0">
                  2
                </span>
                <div>
                  <strong className="text-white">Android Studio'da Açın:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Android Studio'yu çalıştırıp <strong>"Open"</strong> seçeneği ile çıkarttığınız klasörü seçin. Gradle paket senkronizasyonunun bitmesini bekleyin (yaklaşık 1-2 dakika).
                  </p>
                </div>
              </li>

              <li className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0">
                  3
                </span>
                <div>
                  <strong className="text-white">APK'yı Derleyin:</strong>
                  <p className="text-slate-400 mt-0.5">
                    Üst menüden <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> seçeneğine tıklayın.
                    Derleme tamamlandığında sağ altta beliren <em>"locate"</em> bağlantısına tıklayarak <code className="text-cyan-300 font-mono">app-debug.apk</code> dosyasını alın ve TV'nize kurun!
                  </p>
                </div>
              </li>
            </ol>
          </div>
        </div>
      )}
    </div>
  );
};
