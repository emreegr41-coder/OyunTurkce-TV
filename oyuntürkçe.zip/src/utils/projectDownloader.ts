import JSZip from 'jszip';
import { ANDROID_STUDIO_FILES } from '../data/androidProjectFiles';

/**
 * Tekil bir proje dosyasını doğrudan indirir.
 */
export function downloadSingleFile(filename: string, content: string, mimeType: string = 'text/plain') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Tüm Android Studio TV projesini klasör hiyerarşisiyle birlikte
 * tek bir ZIP arşivi olarak üretir ve indirir.
 */
export async function downloadFullProjectZip(onProgress?: (percent: number) => void): Promise<void> {
  const zip = new JSZip();

  // Kök klasör: OyunTurkceTV
  const root = zip.folder('OyunTurkceTV');
  if (!root) throw new Error('ZIP kök dizini oluşturulamadı');

  // Her dosyayı ait olduğu alt klasör yoluna ekle
  Object.values(ANDROID_STUDIO_FILES).forEach((file) => {
    root.file(file.path, file.content);
  });

  // README.md ekle
  root.file(
    'README.md',
    `# OyunTürkçe - Android TV Oyun Altyazı Çevirici Projesi

Bu proje, Android TV ve Google TV cihazlarında çalışmak üzere tasarlanmış tam bir Android Studio projesidir.

## Kurulum ve APK Derleme Adımları:
1. Android Studio'yu açın.
2. "Open Existing Project" seçeneğine tıklayın ve bu klasörü seçin.
3. Gradle senkronizasyonunun bitmesini bekleyin.
4. Menüden: **Build > Build Bundle(s) / APK(s) > Build APK(s)** yolunu izleyin.
5. Oluşan APK \`app/build/outputs/apk/debug/app-debug.apk\` konumunda hazır olacaktır!

## Android TV Özel Yapılandırmaları:
- **touchscreen=false**: TV arayüzünde zorunludur.
- **LEANBACK_LAUNCHER**: Uygulamanın TV ana ekranındaki 'Uygulamalar' satırında görünmesini sağlar.
- **TV Banner (Afiş)**: 320x180 px 16:9 TV afişi tanımlıdır.
- **D-Pad Tuşları**: Kumandanın OK, Yön tuşları ve Geri tuşu yakalanır.
`
  );

  // ZIP'i oluştur ve kullanıcıya indir
  const content = await zip.generateAsync({ type: 'blob' }, (metadata) => {
    if (onProgress) {
      onProgress(Math.round(metadata.percent));
    }
  });

  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'OyunTurkce-AndroidTV-Studio-Projesi.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Sunucudaki statik dosyayı fetch ile blob'a çevirip güvenli şekilde indirir.
 * iFrame sandbox engellemelerini aşar.
 */
export async function downloadStaticFileAsBlob(url: string, filename: string): Promise<void> {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Dosya sunucudan indirilemedi');
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
  } catch (err) {
    console.warn('Blob indirme hatası, doğrudan pencereye yönlendiriliyor:', err);
    window.open(url, '_blank');
  }
}
